package com.example.tester

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
